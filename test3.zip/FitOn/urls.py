"""
URL configuration for FitOn project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
# from .views import signup, homepage, login, password_reset_complete, password_reset_confirm, password_reset_request, password_reset_done, profile_view, upload_profile_picture, deactivate_account, confirm_deactivation
from . import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import path

urlpatterns = [
    path('callback/', views.callback_google_fit, name='callback_google_fit'),
    path('authorize/', views.authorize_google_fit, name='authorize_google_fit'),
    path('admin/', admin.site.urls),
    path('signup/', views.signup, name='signup'),
    path('home/', views.homepage, name='homepage'),
    path('login/', views.login, name='login'),
    path('deactivate/', views.deactivate_account, name='deactivate_account'),
    path('deactivate/confirm/', views.confirm_deactivation, name='confirm_deactivation'),
    path('logout/', views.login, name='logout'),
    path('reset-password/', views.password_reset_request, name='password_reset_request'),
    path('reset-password/<str:user_id>/<str:token>/', views.password_reset_confirm, name='password_reset_confirm'),
    path('reset-password/done/', views.password_reset_done, name='password_reset_done'),
    path('reset-password/complete/', views.password_reset_complete, name='password_reset_complete'),
    path('profile/', views.profile_view, name='profile'),
    path('upload_profile_picture/', views.upload_profile_picture, name='upload_profile_picture'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    

