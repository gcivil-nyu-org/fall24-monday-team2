# fall24-monday-team2

## Team Members:
1. Rohan Chopra
2. Karthik Vadlamudi
3. Steven Granaturov
4. Zejun Zhao
5. Taeyeon 

## Wiki:
https://github.com/gcivil-nyu-org/fall24-monday-team2/wiki